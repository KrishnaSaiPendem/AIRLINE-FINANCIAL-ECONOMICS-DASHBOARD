from flask import Flask, render_template, request
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import MinMaxScaler
from statsmodels.tsa.arima.model import ARIMA
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, GRU
from tensorflow.keras.optimizers import Adam

app = Flask(__name__)

# Load and prepare data
file_path = "E:/Daen 690 Capstone Project/form_41_stock_master_with_types.csv"
df = pd.read_csv(file_path)

# Create Date column and set as index
df['Date'] = pd.to_datetime(df['YEAR'].astype(str) + 'Q' + df['QUARTER'].astype(str))
df.set_index('Date', inplace=True)

# Preprocess function for a single airline
def preprocess_airline(df, airline_name):
    df = df[df['Stock_UNIQUE_CARRIER_NAME'] == airline_name]
    df['ASM'] = df['T1_AVL_SEAT_MILES_320']
    df['RPM'] = df['P12_OP_REVENUES'] / df['ASM']
    df['CASM'] = df['P12_OP_EXPENSES'] / df['ASM']
    df['RASM'] = df['P12_OP_REVENUES'] / df['ASM']
    df['PRASM'] = df['Stock_End_Price'] / df['ASM']
    df['Volatility'] = (df['Stock_High_Price'] - df['Stock_Low_Price']) / df['Stock_Low_Price']
    df['Return'] = df['Stock_End_Price'].pct_change()
    for lag in range(1, 4):
        df[f'Stock_End_Price_lag_{lag}'] = df['Stock_End_Price'].shift(lag)
    df.dropna(inplace=True)
    return df

# Prepare features and target
def prepare_features(df):
    X = df[['ASM', 'RPM', 'CASM', 'RASM', 'PRASM', 'Volatility', 'Return',
            'Stock_End_Price_lag_1', 'Stock_End_Price_lag_2', 'Stock_End_Price_lag_3']]
    y = df['Stock_End_Price']
    return X, y

# Models
def train_arima(y):
    model = ARIMA(y, order=(5, 1, 0))
    model_fit = model.fit()
    predictions = model_fit.predict(start=0, end=len(y)-1)
    return predictions

def train_lstm(train_X, train_y):
    train_X_reshaped = train_X.reshape((train_X.shape[0], train_X.shape[1], 1))
    model = Sequential([
        LSTM(128, activation='relu', input_shape=(train_X.shape[1], 1)),
        Dense(1)
    ])
    model.compile(optimizer=Adam(learning_rate=0.001), loss='mse')
    model.fit(train_X_reshaped, train_y, epochs=100, batch_size=32, verbose=0)
    predictions = model.predict(train_X_reshaped).flatten()
    return predictions

def train_gru(train_X, train_y):
    train_X_reshaped = train_X.reshape((train_X.shape[0], train_X.shape[1], 1))
    model = Sequential([
        GRU(128, activation='relu', input_shape=(train_X.shape[1], 1)),
        Dense(1)
    ])
    model.compile(optimizer=Adam(learning_rate=0.001), loss='mse')
    model.fit(train_X_reshaped, train_y, epochs=100, batch_size=32, verbose=0)
    predictions = model.predict(train_X_reshaped).flatten()
    return predictions

# Visualize Results
def visualize_results(df, y, predictions, title, future_predictions):
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df.index, y=df['Stock_End_Price'], mode='lines', name='Actual Stock Prices'))
    fig.add_trace(go.Scatter(x=df.index, y=predictions, mode='lines', name='Model Predictions'))
    future_dates = pd.date_range(start=df.index[-1] + pd.Timedelta('1D'), periods=3, freq='Q')
    fig.add_trace(go.Scatter(x=future_dates, y=future_predictions, mode='lines', name='Future Predictions'))
    fig.update_layout(
        title=title,
        xaxis_title="Date",
        yaxis_title="Stock Price",
        legend_title="Model"
    )
    return fig.to_html(full_html=False)

@app.route('/')
def index():
    airlines = df['Stock_UNIQUE_CARRIER_NAME'].unique()
    return render_template('index.html', airlines=airlines)

@app.route('/predict', methods=['POST'])
def predict():
    airline_name = request.form['airline']
    airline_df = preprocess_airline(df, airline_name)
    
    # Check if the data for the selected airline exists
    if airline_df.empty:
        return render_template('result.html', airline=airline_name, predictions=[], graph=None)

    X, y = prepare_features(airline_df)

    # Scale features
    scaler = MinMaxScaler()
    scaled_X = scaler.fit_transform(X)

    # Train models
    arima_predictions = train_arima(y)
    lstm_predictions = train_lstm(scaled_X, y)
    gru_predictions = train_gru(scaled_X, y)

    # Ensemble predictions
    ensemble_predictions = (arima_predictions + lstm_predictions + gru_predictions) / 3

    # Future predictions (next 3 quarters)
    future_predictions = ensemble_predictions[-3:].tolist()

    # Visualize results
    graph_html = visualize_results(airline_df, y, ensemble_predictions, f'{airline_name} Stock Price Prediction', future_predictions)

    return render_template('result.html', airline=airline_name, predictions=future_predictions, graph=graph_html)


if __name__ == '__main__':
    app.run(debug=True)
